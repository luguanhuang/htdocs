<?php
require("services/AtherFrameWork.php");

global $Obj_Frame;
global $Ary_Result;

$Obj_Frame = new AtherFrameWork();
$Ary_Result= $Obj_Frame->load_page("SystemSet::getSysInfo");
//print_r($Ary_Result);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>系统状态 - <?=_GLO_PROJECT_FNAME_?></title>
<link type="text/css" rel="stylesheet" href="css.css" />
<style>
.tab2 td {line-height:20px;}
.tab2 tr.blackrow{background-color:#DFDFDF;}
</style>
</head>
<body onload="load_start();">
<form name="SysInfoForm" id="SysInfoForm" action="submit.php" submitwin="ajax" method="post">
<table align="center" cellpadding="0" cellspacing="0" border="0" class="tab2" id="system_status">
  <caption class="nav">
  <div><span></span>系统状态</div>
  </caption>
  <thead>
    <tr class="blackrow">
      <td width="100"></td>
      <td width="100" align="left">总量</td>
      <td width="100" align="left">已使用</td>
      <td align="left">使用率</td>
    </tr>
  </thead>
  <tr>
    <td class="t">CPU：</td>
    <td class="c" id="system_cpu_total">&nbsp;</td>
    <td class="c" id="system_cpu_use">&nbsp;</td>
    <td class="c" id="system_cpu_percent"><?=$Ary_Result['result']['cpuinfo_str']?></td>
  </tr>
  <tr class="blackrow">
    <td class="t">内存：</td>
    <td class="c" id="system_mem_total"><?=$Ary_Result['result']['memtotal']?></td>
    <td class="c" id="system_mem_use"><?=$Ary_Result['result']['memuse']?></td>
    <td class="c" id="system_mem_percent"><?=$Ary_Result['result']['memrate']?></td>
  </tr>
  <tr>
    <td class="t">磁盘空间：</td>
    <td class="c" id="system_hd_total"><?=$Ary_Result['result']['disktotal']?></td>
    <td class="c" id="system_hd_use"><?=$Ary_Result['result']['diskuse']?></td>
    <td class="c" id="system_hd_percent"><?=$Ary_Result['result']['diskrate']?></td>
  </tr>
</table>
	<input name="php_interface" type="hidden" id="php_interface" value="SystemSet::getSysInfo" />
    <input name="php_parameter" type="hidden" id="php_parameter" value="[]" />
    <input name="php_returnmode" type="hidden" id="php_returnmode" value="json" />
</form>

<form name="LanForm" id="LanForm" action="submit.php" submitwin="ajax" method="post" style="display:none;">
<table align="center" cellpadding="0" cellspacing="0" border="0" class="tab2">
  <caption class="nav">
  <div><span></span>LAN口状态</div>
  </caption>
  <tr>
    <td class="t">IP地址：</td>
    <td class="c" id="lan_ip">ip</td>
  </tr>
  <tr class="blackrow">
    <td class="t">默认网关：</td>
    <td class="c" id="lan_netgate">255.255.255.0</td>
  </tr>
  <tr>
    <td class="t">子网掩码：</td>
    <td class="c" id="lan_mask">255.255.255.0</td>
  </tr>
  <tr class="blackrow">
    <td class="t" width="100">广播地址：</td>
    <td class="c" id="lan_broadcast"></td>
  </tr>
</table>
	<input name="php_interface" type="hidden" id="php_interface" value="NetConfig::getLanIP" />
    <input name="php_parameter" type="hidden" id="php_parameter" value="[]" />
    <input name="php_returnmode" type="hidden" id="php_returnmode" value="json" />
</form>

<form name="WanForm" id="WanForm" action="submit.php" submitwin="ajax" method="post" style="display:none;">
<table align="center" cellpadding="0" cellspacing="0" border="0" class="tab2">
  <caption class="nav">
  <div><span></span>WAN口状态</div>
  </caption>
  <tr>
    <td class="t">连接类型：</td>
    <td class="c" id="wan_type"></td>
  </tr>
  <tr id="tr_lantype" name="tr_lantype" remark="(4)3G拨号有效" style="display:none;">
    <td class="t">网卡类型：</td>
    <td class="c" id="wan_lantype"></td>
  </tr>
  <tr id="tr_dailuser" name="tr_dailuser" remark="(2)ADSL拨号有效" style="display:none;">
    <td class="t">拨号用户名：</td>
    <td class="c" id="wan_dailuser"></td>
  </tr>
  <tr id="tr_netgate" name="tr_netgate" remark="(1)静态IP有效" style="display:none;">
    <td class="t">网关：</td>
    <td class="c" id="wan_netgate"></td>
  </tr>
  <tr>
    <td class="t">IP地址：</td>
    <td class="c" id="wan_ip"></td>
  </tr>
  <tr>
    <td class="t">子网掩码：</td>
    <td class="c" id="wan_mask"></td>
  </tr>
  <tr>
    <td class="t" id="wan_broadcasttitle">广播地址：</td>
    <td class="c" id="wan_broadcast"></td>
  </tr>
  <tr>
    <td class="t">首选DNS：</td>
    <td class="c" id="wan_dns1"></td>
  </tr>
   <tr>
    <td class="t">备用DNS：</td>
    <td class="c" id="wan_dns2"></td>
  </tr>
  <tr>
    <td class="t">其他信息：</td>
    <td class="c" id="wan_message"></td>
  </tr>
</table>
	<input name="php_interface" type="hidden" id="php_interface" value="NetConfig::getWanStatus" />
    <input name="php_parameter" type="hidden" id="php_parameter" value="[]" />
    <input name="php_returnmode" type="hidden" id="php_returnmode" value="json" />
</form>
<form name="WConfForm" id="WConfForm" action="submit.php" submitwin="ajax" method="post" style="display:none;">
	<input name="php_interface" type="hidden" id="php_interface" value="NetConfig::getWlanConf" />
    <input name="php_parameter" type="hidden" id="php_parameter" value="[]" />
    <input name="php_returnmode" type="hidden" id="php_returnmode" value="json" />
</form>
<!--
<table align="center" cellpadding="0" cellspacing="0" border="0" class="tab2">
  <caption class="nav">
  <div><span></span>WAN口流量统计</div>
  </caption>
  <thead>
    <tr>
      <td width="100" class="c"></td>
      <td width="120" class="c">接收</td>
      <td class="c">发送</td>
    </tr>
  </thead>
  <tr>
    <td class="t">字节数：</td>
    <td class="c">8923695234</td>
    <td class="c">123695234</td>
  </tr>
  <tr>
    <td class="t">数据包数：</td>
    <td class="c">3695716</td>
    <td class="c">895234</td>
  </tr>
  <tr>
    <td class="t">运行时间：</td>
    <td class="c">2 天 20:25:13 &nbsp;
    </td>
    <td class="c">&nbsp;</td>
  </tr>
  <tr>
    <td class="t">&nbsp;</td>
    <td align="left" colspan="2" class="f"><input type="button" id="btnrefresh" value="刷新" class="btn" onclick="window.location.reload(true);" /></td>
  </tr>
</table>
-->
<form name="TunForm" id="TunForm" action="submit.php" submitwin="ajax" method="post" style="display:none;">
<table align="center" cellpadding="0" cellspacing="0" border="0" class="tab2" id="tun_status">
  <caption class="nav">
  <div><span></span>TUN口状态</div>
  </caption>
  <tr>
    <td class="t" width="100">连接类型：</td>
    <td class="c" id="tun_type"></td>
  </tr>
  <tr class="blackrow">
    <td class="t" width="100">IP地址：</td>
    <td class="c" id="tun_ip"></td>
  </tr>
  <tr>
    <td class="t">子网掩码：</td>
    <td class="c" id="tun_mask"></td>
  </tr>
  <tr class="blackrow">
    <td class="t">广播地址：</td>
    <td class="c" id="tun_broadcast"></td>
  </tr>
  <tr>
    <td class="t">首选DNS服务器：</td>
    <td class="c" id="tun_dns1"></td>
  </tr>
  <tr class="blackrow">
    <td class="t">备用DNS服务器：</td>
    <td class="c" id="tun_dns2"></td>
  </tr>
  <tr style="height:40px;height:30px \9;">
    <td class="t">&nbsp;</td>
    <td align="left"><input type="button" title="重启过程需要一段时间，请耐心等等" value="重启安全接入服务" class="btn" onclick="return SecClient_Restart(this);"  action="submit.php?php_interface=SafetySet::restartSafe&php_parameter=[]&php_returnmode=normal" submitwin="ajax"/></td>
  </tr>
</table>
	<input name="php_interface" type="hidden" id="php_interface" value="SafetySet::getSafeStatus" />
    <input name="php_parameter" type="hidden" id="php_parameter" value="[]" />
    <input name="php_returnmode" type="hidden" id="php_returnmode" value="json" />
</form>

<br clear="all" />
<?php
require('footer.html');
require('loadjs.html');
?>
<script type="text/javascript" src="js/status.js"></script>
<?php
unset($Ary_Result); $Ary_Result = NULL;
unset($Obj_Frame);	$Obj_Frame  = NULL;
?>
</body>
</html>