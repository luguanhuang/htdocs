<?php require("services/Config.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>用户登录 - <?=_GLO_PROJECT_FNAME_?></title>
<link type="text/css" rel="stylesheet" href="css.css" />
</head>
<body>
<form name="frm" id="frm" action="submit.php" onsubmit="javascript:return Login_Validate(this);"  submitwin="ajax" method="post">
  <table id="tablogin" align="center" border="0" cellpadding="0" cellspacing="0">
   <caption class="nav"><div><span></span>系统登录</div></caption>
    <tr>
      <td colspan="2" style="height:15px;"></td>
    </tr>
    <tr>
      <td valign="middle" class="f14 t">用户名：</td>
      <td align="left"><input id="username" name="username" type="text" style="width:150px" tabindex="1" autocomplete="off" value="" class="input" /></td>
    </tr>
    <tr>
      <td valign="middle" class="f14 t">密&nbsp;&nbsp;码：</td>
      <td align="left"><input id="password" name="password" type="password" style="width:150px" tabindex="2" class="input" /></td>
    </tr>
    <?php if (_GLO_USER_LOGIN_VCODE_){?>
    <tr>
      <td valign="middle" class="f14 t">验证码：</td>
      <td align="left">
      	<div style="float:left;display:inline;margin:4px 6px 0px 0px;-margin-right:3px;"><input type="text" name="vcode" id="vcode" tabindex="3" style="width:48px;" autocomplete="off" class="input" title="请输入右图中的文字" /></div>
        <img src="vcode.php" name="rndimg" align="absmiddle" id="rndimg" style="cursor:pointer;" title="点击换一张" onclick="this.src=this.src+'?'+Math.random();" /></td>
    </tr>
    <?php }?>
    <tr>
      <td align="center" colspan="2"  class="f2">
      	<div class="left130">
      	<input type="submit" name="cmdlogin" id="cmdlogin" value="登录" tabindex="4" class="btn"/>
        <input type="reset" name="btnreset" id="btnreset" value="重置" tabindex="5" class="btn" />
        </div>
        </td>
    </tr>
  </table>
  <input name="php_interface" type="hidden" id="php_interface" value="UserManager::login" />
  <input name="php_parameter" type="hidden" id="php_parameter" value="['username','password','vcode']" />
  <input name="php_returnmode" type="hidden" id="php_returnmode" value="json" />
</form>
<?php
require('loadjs.html');
?>
<script type="text/javascript" src="js/enter.js"></script>
</body>
</html>