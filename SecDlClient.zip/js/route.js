// JavaScript Document

function Route_Delete($id){
	$_C.Confirm(
		"路由配置记录删除后将不可恢复，您确定要删除该记录？",
		function ($route){
			var $form	= document.forms.frm;
			if (!$form){ return false; }
			var $int_id	 = $_G.intval($route);
			var $obj_row = $('row_'+$int_id);
			var $ary_conf= ["type","ip","mask","netgate","ifname"]
			var $obj_conf= null, $obj_value=null, $k;
			for($k in $ary_conf){
				$obj_value = $($ary_conf[$k]+"_"+$int_id);
				$obj_conf = $form.elements[$ary_conf[$k]];
				if (!$obj_value || !$obj_conf){ return false; }
				$obj_conf.value = $obj_value.value;
			}
			AjaxSubmit(
				$form,
				{
					"backcall":function($row){
						if ($row){
							$_C.Alert($_A.result()[3],null);
							$row.parentNode.removeChild($row);
						}
						else{
							$_C.Alert($_A.result()[3], function (){ window.location.reload(true); } );
						}
					},
					"backargs":null
				},
				$obj_row
			);
			return false;
		},
		null,
		$id
	)
	return false;
}

function Route_Validate($form){
	if (!$form){ return false; }
	//验证表单
	var	$ary_element = new Array();
		$ary_element["ip"]		= new Array(7,	15,		'网段',			"ip");
		$ary_element["type"]	= new Array(1,	null,	'路由类型',		false);
		$ary_element["mask"]	= new Array(0,	null,	'子网掩码',		SelectRegRule('mask'));
		$ary_element["netgate"]	= new Array(1,	null,	'网关IP地址',		"ip");
		$ary_element["ifname"]	= new Array(1,	null,	'接口名称',		false);
		
	$_G.Form	= $form;
	$_G.Element	= $ary_element;
	
	if (!$_G.submit()){$_C.Alert($_G.Error()+"！",$_G.errfocus); return false;}

	//提交数据
	return AjaxSubmit(
		$form,
		{
			"backcall":function($frm){
				$_C.Confirm(
					$_A.result()[3]+" 您是否要继续添加路由器？",
					function (){$frm.reset(1);},
					function (){window.location.href='route.php';}
				)
			},
			"backargs":[$form]
		}
	);
}