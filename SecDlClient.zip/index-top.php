<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link type="text/css" rel="stylesheet" href="css.css" />
</head>
<body style="background-color:#0731A5;padding-top:0;">
<table height="100" cellSpacing="0" cellPadding="0" width="100%" border="0" align="center" style="background:url(images/banner.gif) no-repeat left top;">
  <tr>
    <td title="永达互联网接入管控器" style="min-width:400px;">&nbsp;</td>
    <td id="tabtop">
    	<div><a href="#" onclick="(function(){
    if (parent.leftFrame && typeof(parent.leftFrame.gotoHome)=='function'){ parent.leftFrame.gotoHome(); }
    })();return false;" style="margin-right:12px;"><img src="images/home.gif" title="首页" alt="首页"  class="btn2"/></a><a href="#" onclick="(function(){
    if (parent.leftFrame && typeof(parent.leftFrame.gotoLogout)=='function'){ parent.leftFrame.gotoLogout(); }
    })();return false;"><img src="images/logout.gif" title="注销" alt="注销" class="btn2" /></a></div>
    	<div class="datetime">当前时间：<b id="datetime"><?=date("Y-m-d H:i:s")?></b></div>
        <br clear="all" />
    </td>
  </tr>
</table>
<script type="text/javascript" src="js/systemset.js"></script>
<script type="text/javascript">DateTime_StartCount(<?=time()?>)</script>
</body>
</html>